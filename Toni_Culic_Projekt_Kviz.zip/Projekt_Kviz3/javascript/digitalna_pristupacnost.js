
    function colorElement(){
        var body=document.body;
        body.style['filter']="grayscale(100%)";
        body.style.backgroundColor = "grey"; 
    }
    function Diskelksija(){
        var disleksija=document.getElementById("sadrzaj");
        disleksija.style.fontFamily="sans";
        disleksija.style.textAlign="left";
        disleksija.style.fontSize="12pt";
    }