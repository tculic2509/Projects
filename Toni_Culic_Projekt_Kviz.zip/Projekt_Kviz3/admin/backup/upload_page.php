<!DOCTYPE html>
<html>

<head lang="en">
    <title>Upload database</title>
    <link rel="stylesheet" href="../../dizajn/dizajn.css">
</head>

<body>
    <?php
    include './upload.php';
    ?>

</body>
<?php
include '../../include/templates/footer.tpl.php';
?>