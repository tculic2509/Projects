<?php
include '../include/baza.php';
?>
<title>Statistika</title>
<?php include('../include/templates/header2.tpl.php') ?>
<?php include('../include/templates/header.tpl.php') ?>
<br>
<?php
$sql = "SELECT  username,AVG(score) FROM highscore GROUP BY username;";
$sql2 = "SELECT  AVG(score) FROM highscore";
$result = mysqli_query($db, $sql);
$result2 = mysqli_query($db, $sql2);

echo '<table border="1" > 
        <tr>  
            <th>Username</th>  
            <th>Average score</th> 
        </tr>';

while ($row = mysqli_fetch_array($result)) {

    echo '
        <tr>
            <td style="font-size: 20px; text-align:center;">' . $row['username'] . '</td> 
            <td style="font-size: 20px">' . $row['AVG(score)'] . '</td>
        </tr>';
}
while ($row = mysqli_fetch_array($result2)) {

    echo '
        <tr>
            <td style="font-size: 20px">Average score of all users</td> 
            <td style="font-size: 20px">' . $row['AVG(score)'] . '</td>
        </tr>';
}
echo '</table>';

?>
<br>
<form action="" method="POST">
    <label>Trazi po mjesecu</label>
    <br>
    <input type="text" name="mjesec" id="mjesec">
    <input type="submit" name="poMjesecu" id="submit" onclick="ajax(event);">
</form>
<div id="displaydata">
    <?php
    //Prikaz highscore iz db

    if (isset($_POST['poMjesecu'])) {
        $mjesec = $_POST['mjesec'];
        $asc_query = "SELECT * FROM highscore WHERE MONTH(rangPoMjesecu)='$mjesec'";
        $result = sendQuery($asc_query, $db);
        $count = 0;

        while ($row = mysqli_fetch_array($result)) {

            $count++;

            echo '<table border="1" > 
                        <tr>  
                               <th>Redni Broj</th> 
                               <th>Username</th>  
                               <th>Score</th>  
                               <th>Vrijeme</th>  
                               <th>Mjesec</th>
                        </tr>  
                        <tr> 
                            <td>' . $count . '</td> 
                            <td>' . $row['username'] . '</td> 
                            <td>' . $row['score'] . '</td> 
                            <td>' . $row['vrijeme'] . '</td>
                            <td>' . $row['rangPoMjesecu'] . '</td>
                        </tr>
                        </table>';
        }
    }
    ?>

</div>

<?php include('../include/templates/footer.tpl.php') ?>