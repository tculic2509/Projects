<?php
include '../include/baza.php';
//provjera jesi logirani korisnik admin
$username = $_COOKIE['user'];
$pass = $_COOKIE['pass'];
$select = mysqli_query($db, "SELECT * FROM korisnik WHERE username='$username' AND pass='$pass'");
$row = mysqli_fetch_assoc($select);
if (($username == $row['username'] && $pass == $row['pass'] && $row['IsAdmin'] == 1)) {
    $isLogedIn = true;
} else {
    header("Location:../user/login.php");
}

$message = '';

if (isset($_POST['logout'])) {
    setcookie(
        'user',
        "",
    );
    setcookie(
        'pass',
        "",
    );
    header("Location:../user/login.php");
}


// admin
$message = '';
if (isset($_POST['formSubmit'])) {
    $pitanje = $_POST['pitanje'];
    $opcija1 = $_POST['opcija1'];
    $opcija2 = $_POST['opcija2'];
    $opcija3 = $_POST['opcija3'];
    $opcija4 = $_POST['opcija4'];
    $odgovor = $_POST['odgovor'];


    $sql = "INSERT INTO pitanja (pitanje, opcija1, opcija2, opcija3, opcija4,odgovor)
                VALUES ('$pitanje', '$opcija1','$opcija2','$opcija3','$opcija4','$odgovor')";
    $result = sendQuery($sql, $db);
    if ($result === true) {
    } else {
    }
}

if (isset($_POST['formDelete'])) {
    $pitanjeID = $_POST['pitanjeID'];
    $sql = "DELETE FROM pitanja WHERE pitanjeID='$pitanjeID'";
    $result = mysqli_query($db, $sql);
    if ($result === true) {
    } else {
    }
    sendQuery("ALTER TABLE pitanja AUTO_INCREMENT=1", $db);
}

if (isset($_POST['formUpdate'])) {
    $pitanjeID = $_POST['pitanjeID'];
    $pitanje = $_POST['pitanje'];
    $opcija1 = $_POST['opcija1'];
    $opcija2 = $_POST['opcija2'];
    $opcija3 = $_POST['opcija3'];
    $opcija4 = $_POST['opcija4'];
    $odgovor = $_POST['odgovor'];
    $sql = "UPDATE pitanja SET pitanje='$pitanje', opcija1='$opcija1', opcija2='$opcija2', opcija3='$opcija3', opcija4='$opcija4',odgovor='$odgovor' WHERE pitanjeID='$pitanjeID'";
    $result = mysqli_query($db, $sql);

    sendQuery("ALTER TABLE pitanja AUTO_INCREMENT=1", $db);
    if ($result === true) {
    } else {
    }
}
//admin postavlja koliko kolačić traje
if (isset($_POST['formCookie'])) {
    $trajanje = $_POST['poljezavrijednostcookiea_i_logina'];
    $sql = "UPDATE adminopcije SET trajanjecookie='$trajanje'";
    sendQuery($sql, $db);
}

if (isset($_POST['formLogin'])) {
    $trajanje = $_POST['poljezavrijednostcookiea_i_logina'];
    $sql = "UPDATE adminopcije SET pokusajlogin='$trajanje'";
    sendQuery($sql, $db);
}
//admin postavlja opcije o korisnicama
if (isset($_POST['formKorisnik'])) {
    $Username = $_POST['Username'];
    $IsAdmin = $_POST['IsAdmin'];
    $stanjeracuna = $_POST['stanjeracuna'];
    $sql = "UPDATE korisnik SET IsAdmin='$IsAdmin',stanjeracuna='$stanjeracuna' WHERE username='$Username'";
    sendQuery($sql, $db);
}


?>
<title>Administrator</title>
<?php include('../include/templates/header2.tpl.php') ?>
<?php include('../include/templates/header.tpl.php') ?>
<?php include('../include/templates/admin.tpl.php') ?>
<?php include('../include/templates/footer.tpl.php') ?>