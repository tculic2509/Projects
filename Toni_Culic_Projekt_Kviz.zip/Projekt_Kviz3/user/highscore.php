<!DOCTYPE html>

<head>
    <title>Highscore</title>

    <form method="POST" id="searching">
        <input type="text" name="search" id="searchbar" placeholder="Pretraži...">
        <button name="submit">Search</button>
        <br><br>
        <div id="admin_div">
            <button class="nas"><a href="../user/naslovna.php">Naslovna</a></button>
            <button class="nas"> <a href="../dokumentacija/autor.html">O nama</a></button>
            <button class="nas"> <a href="../dokumentacija/dokumentacija.html">Dokumentacija</a></button>
            <button class="nas"> <a href="../user/login.php?=logout=1">Logout</a></button>
        </div>
    </form>

    <?php
    include '../include/baza.php';
    include '../include/templates/header.tpl.php';
    ?>

<body>
    <?php
    include '../include/sort_trazi.php';
    ?>
    <?php

    include '../include/templates/footer.tpl.php';
    ?>
</body>

</html>