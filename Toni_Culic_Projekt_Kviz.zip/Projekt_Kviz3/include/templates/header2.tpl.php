<link rel="stylesheet" href="../dizajn/dizajn.css">
<div id="admin_div">
    <button class="nas"><a href="../user/naslovna.php">Naslovna</a></button>
    <button class="nas"> <a href="../dokumentacija/autor.html">O nama</a></button>
    <button class="nas"> <a href="../dokumentacija/dokumentacija.html">Dokumentacija</a></button>
    <button class="nas"> <a href="../user/login.php?=logout=1">Logout</a></button>
</div>