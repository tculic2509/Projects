<!DOCTYPE html>
<html>
<head lang="en">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="../dizajn/dizajn.css" >
    
    <div class="inval">
        <button class="bGrey" onclick="colorElement();">Crno-bijelo</button>
        <button class="dis" onclick="Diskelksija();">Disleksija</button>
    </div>
<body>
    